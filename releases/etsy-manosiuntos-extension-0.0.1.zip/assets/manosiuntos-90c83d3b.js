(function () {
	'use strict';

	const importPath = /*@__PURE__*/JSON.parse('"../content/manosiuntos.js"');

	import(chrome.runtime.getURL(importPath));

}());
